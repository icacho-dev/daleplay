angular.module('App',[]) 
.controller('DashboardController',function($scope){
	console.info('ini DashboardController');

	$scope.filterActive =  "";
	$scope.catActive =  "";
	$scope.splashActive =  "";

	$scope.selectcategoria = function(cat , item){
		console.info(item);
		$scope.filterActive = item.filter;
		$scope.catActive = cat;
		console.info("filterActive:" + $scope.filterActive);
		console.info("catActive:" +$scope.catActive.titulo);
	};

	$scope.app = {
		categorias:[		
			{
				titulo:"Español" ,
				lista: [
					{icono:"plus-square",titulo:"Espectaculos",filter:"Espectaculos"},
					{icono:"plus-square",titulo:"Noticias",filter:"Noticias"},
					{icono:"plus-square",titulo:"Notas Locas",filter:"Notas Locas"},
					{icono:"plus-square",titulo:"Tema del día",filter:"Tema del día"},
					{icono:"plus-square",titulo:"Cine",filter:"Cine"},
					{icono:"plus-square",titulo:"Sabias Que",filter:"Sabias Que"},
					{icono:"plus-square",titulo:"Deportes",filter:"Deportes"},
					{icono:"plus-square",titulo:"Sexo",filter:"Sexo"},
					{icono:"hand-o-up",titulo:"Horoscopos",filter:"Horoscopos"},
				]
			},
			{
				titulo:"Ingles" ,
				lista: [
					{icono:"plus-square",titulo:"Espectaculos",filter:"Espectaculos"},
					{icono:"plus-square",titulo:"Noticias",filter:"Noticias"},
					{icono:"hand-o-up",titulo:"Notas Locas",filter:"Notas Locas"},
					{icono:"plus-square",titulo:"Tema del día",filter:"Tema del día"},
					{icono:"plus-square",titulo:"Cine",filter:"Cine"},
					{icono:"plus-square",titulo:"Sabias Que",filter:"Sabias Que"},
				]
			}
		],
		items:[
			{titulo:"Los Auténticos Decadentes presentarán Y la banda sigue en el Palacio de los Deportes",filter:"Espectaculos",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Muere reina de belleza de Ecuador en cirugía estética",filter:"Espectaculos",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Llega a las salas el filme sobre Pablo Escobar",filter:"Espectaculos",texto:"Escobar, dirigida por Andrea Di Stefano y protagonizada por Josh Hutcherson, Claudia Traisac y Benicio del Toro, se estrena este jueves en salas comerciales. Andrea Di Stefano señaló que la idea de hacer la película surgió cuando uno de sus amigos de la policía le contó la historia de un hombre a quien Pablo Escobar le confió la misión de guardar su tesoro."},
			{titulo:"Volverá Slash a México; dará tres conciertos",filter:"Espectaculos",texto:"Slash, uno de los mejores guitarristas de todos los tiempos y miembro del Salón de la Fama del Rocanrol, regresará a México para ofrecer tres espectaculares y explosivos conciertos en marzo próximo. Primero se presentará en el Pepsi Center de la ciudad de México, el 25 de marzo, seguirá el 26 en el Teatro Estudio Cavaret de Guadalajara y por último llegará el 28 de marzo al auditorio Banamex de Monterrey."},
			{titulo:"Objeto Nota - 1",filter:"Espectaculos",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 1",filter:"Espectaculos",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 1",filter:"Espectaculos",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 1",filter:"Espectaculos",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 1",filter:"Espectaculos",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 2",filter:"Noticias",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 2",filter:"Noticias",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 2",filter:"Noticias",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 3",filter:"Notas Locas",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 3",filter:"Notas Locas",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 4",filter:"Tema del día",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 5",filter:"Cine",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 6",filter:"Sabias Que",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 6",filter:"Sabias Que",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 7",filter:"Deportes",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 8",filter:"Sexo",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 9",filter:"Horoscopos",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
			{titulo:"Objeto Nota - 9",filter:"Horoscopos",texto:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text scrambled it to make a type specimen book."},
		]
	}; 
})
;