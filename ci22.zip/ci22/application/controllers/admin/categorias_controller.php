<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Categorias_controller extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$dbconnect = $this->load->database();

		$this->load->model('Categorias_model');

		$this->Categorias_model->insert_categoria('cat1');


		$data['main_content'] = 'admin/categorias_view';	
		$this->load->view('templates/adminpanel',$data);	
	}

}

/* End of file admin_controller.php */
/* Location: ./application/controllers/admin_controller.php */