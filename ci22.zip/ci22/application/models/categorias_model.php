<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Categorias_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}

	function get_last_item()
	{
	$this->db->order_by('PK_IdCategoria', 'DESC');
	$query = $this->db->get('Nombre', 1);

	return $query->result();
	}

	function insert_categoria($nombre)
	{
	$data = array(
		'Nombre' => $nombre
		);

	$this->db->insert_string('Categorias', $data);
	}

}

/* End of file categorias_model.php */
/* Location: ./application/models/categorias_model.php */