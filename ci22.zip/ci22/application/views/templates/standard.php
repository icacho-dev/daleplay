<?php

$this->load->view('includes/header.php');

$this->load->view($main_content);

$this->load->view('includes/footer.php');