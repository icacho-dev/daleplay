<div class="clearfix"></div>

<div class="menu_shadow">dhf</div>

<div class="clearfix margin_top10"></div>

<div class="page_title2">
<div class="container">
    
    <h1>{{filterActive}}</h1>
    <div class="pagenation">&nbsp;<a href="index.html">Textos</a> <i>/</i> <a href="#">{{catActive.titulo}}</a> <i>/</i> {{filterActive}}</div>
     
</div>
</div>
<!-- end page title -->
<div class="clearfix"></div>

<div class="content_fullwidth less2">
<div class="container">

	<div class="reg_form">
        <form id="sky-form" class="sky-form">
				<header>Agregar categoria</header>
				
				<fieldset>					
					<section>
						<label class="input">
							<i class="icon-append fa-newspaper-o"></i>
							<input type="text" name="Nombre" placeholder="Nombre" required>
							<!--<b class="tooltip tooltip-bottom-right">Nombre de contenido</b>-->
						</label>
					</section>

                    <section>
                        <label class="input">
                            <i class="icon-append fa-newspaper-o"></i>
                            <input type="text" name="Icono" placeholder="Icono">
                            <!--<b class="tooltip tooltip-bottom-right">Icono de contenido</b>-->
                        </label>
                    </section>
					
				</fieldset>					
				
				<footer>
					<button type="submit" class="button">Guardar</button>
				</footer>
			</form>			
		</div>
    

</div>
</div><!-- end content area -->