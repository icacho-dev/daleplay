<div class="clearfix marb12"></div>

<footer class="footer style3">

<div class="container">
 </div><!-- end footer -->

<div class="clearfix"></div>

<div class="copyright_info">
<div class="container">

    <div class="clearfix divider_dashed10"></div>
    
    <div class="one_half animate" data-anim-type="fadeInRight">
    
        Copyright © 2014 Aaika.com. All rights reserved.  <a href="#">Terms of Use</a> | <a href="#">Privacy Policy</a>
        
    </div>
    
    <div class="one_half last">
        
        <ul class="footer_social_links">
            <li class="animate" data-anim-type="zoomIn"><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li class="animate" data-anim-type="zoomIn"><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li class="animate" data-anim-type="zoomIn"><a href="#"><i class="fa fa-google-plus"></i></a></li>
            <li class="animate" data-anim-type="zoomIn"><a href="#"><i class="fa fa-linkedin"></i></a></li>
            <li class="animate" data-anim-type="zoomIn"><a href="#"><i class="fa fa-skype"></i></a></li>
            <li class="animate" data-anim-type="zoomIn"><a href="#"><i class="fa fa-flickr"></i></a></li>
            <li class="animate" data-anim-type="zoomIn"><a href="#"><i class="fa fa-html5"></i></a></li>
            <li class="animate" data-anim-type="zoomIn"><a href="#"><i class="fa fa-youtube"></i></a></li>
            <li class="animate" data-anim-type="zoomIn"><a href="#"><i class="fa fa-rss"></i></a></li>
        </ul>
            
    </div>
    
</div>
</div><!-- end copyright info -->


</footer>


<a href="#" class="scrollup">Scroll</a><!-- end scroll to top of the page-->





</div>

    
<!-- ######### JS FILES ######### -->
<!-- get jQuery from the google apis -->
<script type="text/javascript" src="<?php echo base_url();?>js/universal/jquery.js"></script>

<!-- style switcher -->
<script src="<?php echo base_url();?>js/style-switcher/jquery-1.js"></script>
<script src="<?php echo base_url();?>js/style-switcher/styleselector.js"></script>

<!-- animations -->
<script src="<?php echo base_url();?>js/animations/js/animations.min.js" type="text/javascript"></script>

<!-- slide panel -->
<script type="text/javascript" src="<?php echo base_url();?>js/slidepanel/slidepanel.js"></script>

<!-- mega menu -->
<script src="<?php echo base_url();?>js/mainmenu/bootstrap.min.js"></script> 
<script src="<?php echo base_url();?>js/mainmenu/customeUI.js"></script> 

<!-- scroll up -->
<script src="<?php echo base_url();?>js/scrolltotop/totop.js" type="text/javascript"></script>

<!-- sticky menu -->
<script type="text/javascript" src="<?php echo base_url();?>js/mainmenu/sticky-6.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/mainmenu/modernizr.custom.75180.js"></script>


<script type="text/javascript" src="<?php echo base_url();?>js/universal/custom.js"></script>


</body>
</html>